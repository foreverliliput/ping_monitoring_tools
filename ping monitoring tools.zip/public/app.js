// ============================================================================
// State
// ============================================================================
let TOKEN = localStorage.getItem("noc_token") || null;
let devices = [];
let rules = [];
let routers = [];
let pinned = new Set(JSON.parse(localStorage.getItem("noc_pinned") || "[]"));
let selected = new Set();
let sortState = { col: "name", dir: 1 };
let ws = null;

// ============================================================================
// API helper
// ============================================================================
async function api(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}),
      ...(options.headers || {}),
    },
  });
  if (res.status === 401) {
    logout("Your session ended (the server may have restarted) - please log in again.");
    throw new Error("Session expired - please log in again");
  }
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `Request failed (${res.status})`);
  return body;
}

// ============================================================================
// Auth
// ============================================================================
function logout(reason) {
  TOKEN = null;
  localStorage.removeItem("noc_token");
  if (ws) ws.close();
  closeModal(); // an expired session mid-edit must not leave the modal frozen on top of the login screen
  document.getElementById("alerts-panel").classList.add("hidden");
  document.getElementById("app").classList.add("hidden");
  document.getElementById("login-screen").classList.remove("hidden");
  document.getElementById("login-error").textContent = reason || "";
}

async function login() {
  const password = document.getElementById("login-password").value;
  const errorEl = document.getElementById("login-error");
  errorEl.textContent = "";
  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Login failed");
    TOKEN = body.token;
    localStorage.setItem("noc_token", TOKEN);
    await boot();
  } catch (err) {
    errorEl.textContent = err.message;
  }
}

async function boot() {
  document.getElementById("login-screen").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");
  connectWebSocket();
  await loadRouters(); // load first - device server-filter dropdown depends on this list
  await Promise.all([loadDevices(), loadRules()]);
  renderGrid();
  renderRules();
  renderRouters();
  loadAlertEvents();
  loadSettings();
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
  }
}

// ============================================================================
// WebSocket - real-time updates
// ============================================================================
function connectWebSocket() {
  const proto = location.protocol === "https:" ? "wss:" : "ws:";
  ws = new WebSocket(`${proto}//${location.host}/ws?token=${TOKEN}`);

  ws.onopen = () => setWsIndicator(true);
  ws.onclose = () => {
    setWsIndicator(false);
    setTimeout(() => { if (TOKEN) connectWebSocket(); }, 3000); // auto-reconnect
  };
  ws.onerror = () => setWsIndicator(false);

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === "device.stats.update") {
      const device = devices.find((d) => d.id === msg.payload.deviceId);
      if (device) {
        device.stats = msg.payload.reset ? null : msg.payload;
        renderGrid();
      }
    } else if (msg.type === "alert.triggered") {
      showBrowserNotification(msg.payload.message);
      playAlertSound();
      loadAlertEvents();
    } else if (msg.type === "alert.resolved") {
      loadAlertEvents();
    } else if (msg.type === "traceroute.update") {
      // handled inline when the traceroute modal is open; no-op otherwise
    }
  };
}

function setWsIndicator(connected) {
  const el = document.getElementById("ws-indicator");
  el.textContent = connected ? "🟢 live" : "🔴 reconnecting…";
  el.className = connected ? "pill pill-online" : "pill pill-offline";
}

function showBrowserNotification(message) {
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification("NOC Alert", { body: message });
  }
}

// Generated with the Web Audio API rather than an audio file, so there's
// nothing extra to bundle/host - just a short two-tone "alert" beep.
let audioCtx = null;
function playAlertSound() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const now = audioCtx.currentTime;
    [880, 660].forEach((freq, i) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      const start = now + i * 0.18;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.3, start + 0.02);
      gain.gain.linearRampToValueAtTime(0, start + 0.16);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(start);
      osc.stop(start + 0.18);
    });
  } catch {
    // Audio can fail if the browser hasn't seen a user gesture yet, or
    // doesn't support the Web Audio API - never let a beep failure break
    // the actual alert notification flow.
  }
}

// ============================================================================
// Devices
// ============================================================================
async function loadDevices() {
  const params = new URLSearchParams();
  const search = document.getElementById("search-input")?.value;
  const category = document.getElementById("filter-category")?.value;
  const pop = document.getElementById("filter-pop")?.value;
  const status = document.getElementById("filter-status")?.value;
  const server = document.getElementById("filter-server")?.value;
  if (search) params.set("search", search);
  if (category) params.set("category", category);
  if (pop) params.set("pop", pop);
  if (status) params.set("status", status);
  if (server) params.set("server", server);

  const body = await api(`/devices?${params.toString()}`);
  devices = body.devices;
  populateFilterOptions();
}

function populateFilterOptions() {
  const categories = [...new Set(devices.map((d) => d.category).filter(Boolean))].sort();
  const pops = [...new Set(devices.map((d) => d.pop).filter(Boolean))].sort();

  fillSelect("filter-category", categories);
  fillSelect("filter-pop", pops);
  populateServerFilter();
}

function populateServerFilter() {
  const select = document.getElementById("filter-server");
  const current = select.value;
  select.innerHTML = `<option value="">All Servers</option><option value="local">Local Server</option>`;
  for (const r of routers) {
    const opt = document.createElement("option");
    opt.value = r.id;
    opt.textContent = `MikroTik: ${r.name}`;
    select.appendChild(opt);
  }
  select.value = current;
}

function serverLabel(device) {
  if (!device.mikrotikRouterId) return "Local";
  const router = routers.find((r) => r.id === device.mikrotikRouterId);
  return router ? router.name : "Unknown server";
}

function fillSelect(id, values) {
  const select = document.getElementById(id);
  const current = select.value;
  const placeholder = select.options[0];
  select.innerHTML = "";
  select.appendChild(placeholder);
  for (const v of values) {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    select.appendChild(opt);
  }
  select.value = current;
}

function statusDot(status) {
  const cls = status === "ONLINE" ? "status-online" : status === "OFFLINE" ? "status-offline" : "status-unknown";
  return `<span class="status-dot ${cls}"></span>`;
}

function fmt(v, suffix = "", decimals = null) {
  if (v === null || v === undefined || v === "") return "–";
  if (decimals !== null && typeof v === "number") return `${v.toFixed(decimals)}${suffix}`;
  return `${v}${suffix}`;
}

function timeAgo(iso) {
  if (!iso) return "–";
  const diffSec = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diffSec < 5) return "just now";
  if (diffSec < 60) return `${diffSec}s ago`;
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  return `${Math.floor(diffSec / 86400)}d ago`;
}

function sortedFilteredDevices() {
  const list = [...devices];
  list.sort((a, b) => {
    const av = sortValue(a, sortState.col);
    const bv = sortValue(b, sortState.col);
    if (av === bv) return 0;
    if (av === null || av === undefined) return 1;
    if (bv === null || bv === undefined) return -1;
    return (av > bv ? 1 : -1) * sortState.dir;
  });
  // pinned rows always float to top
  list.sort((a, b) => (pinned.has(b.id) ? 1 : 0) - (pinned.has(a.id) ? 1 : 0));
  return list;
}

function sortValue(device, col) {
  const statFields = [
    "currentLatencyMs", "packetLossPercent", "sentCount", "receivedCount", "avgPingMs", "jitterMs",
  ];
  if (statFields.includes(col)) return device.stats ? device.stats[col] : null;
  return device[col];
}

function renderGrid() {
  const tbody = document.getElementById("device-grid-body");
  const list = sortedFilteredDevices();
  const groupBy = document.getElementById("group-by").value;

  document.getElementById("empty-state").classList.toggle("hidden", devices.length > 0);

  tbody.innerHTML = "";

  const online = devices.filter((d) => d.stats?.status === "ONLINE").length;
  const offline = devices.filter((d) => d.stats?.status === "OFFLINE").length;
  document.getElementById("stat-total").textContent = `${devices.length} services`;
  document.getElementById("stat-online").textContent = `${online} online`;
  document.getElementById("stat-offline").textContent = `${offline} offline`;

  let lastGroup = null;
  for (const d of list) {
    if (groupBy) {
      const groupVal = d[groupBy] || "(none)";
      if (groupVal !== lastGroup) {
        lastGroup = groupVal;
        const tr = document.createElement("tr");
        tr.className = "group-row";
        tr.innerHTML = `<td colspan="14">${groupVal}</td>`;
        tbody.appendChild(tr);
      }
    }
    tbody.appendChild(renderRow(d));
  }

  document.getElementById("bulk-edit-btn").classList.toggle("hidden", selected.size === 0);
  document.getElementById("bulk-delete-btn").classList.toggle("hidden", selected.size === 0);
  document.getElementById("bulk-count").textContent = selected.size;
  document.getElementById("refresh-all-btn").textContent =
    selected.size > 0 ? `↻ Refresh Selected (${selected.size})` : "↻ Refresh All";
}

function renderRow(d) {
  const s = d.stats || {};
  const tr = document.createElement("tr");
  if (pinned.has(d.id)) tr.classList.add("pinned");

  tr.innerHTML = `
    <td><input type="checkbox" class="row-check" data-id="${d.id}" ${selected.has(d.id) ? "checked" : ""} /></td>
    <td><button class="pin-btn ${pinned.has(d.id) ? "active" : ""}" data-pin="${d.id}">📌</button></td>
    <td>${statusDot(s.status)}${escapeHtml(d.name)}</td>
    <td>${escapeHtml(d.ipAddress)}</td>
    <td>${escapeHtml(d.category || "–")}</td>
    <td>${escapeHtml(serverLabel(d))}</td>
    <td>${fmt(s.currentLatencyMs, "ms", 3)}</td>
    <td>${fmt(s.packetLossPercent, "%", 2)}</td>
    <td>${fmt(s.sentCount)}</td>
    <td>${fmt(s.receivedCount)}</td>
    <td>${fmt(s.avgPingMs, "ms", 3)}</td>
    <td>${fmt(s.jitterMs, "ms", 3)}</td>
    <td>${escapeHtml(d.notes || "")}</td>
    <td>
      <button class="btn small" data-traceroute="${d.id}">Trace</button>
      <button class="btn small" data-refresh="${d.id}" title="Reset stats and start a fresh ping report">↻</button>
      <button class="btn small" data-edit="${d.id}">Edit</button>
      <button class="btn small danger" data-delete="${d.id}">Del</button>
    </td>
  `;
  return tr;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// ---- Add/Edit device modal ----
function openDeviceModal(device = null) {
  const isEdit = !!device;
  const currentServer = device?.mikrotikRouterId || "local";
  const routerOptions = routers
    .map((r) => `<option value="${r.id}" ${currentServer === r.id ? "selected" : ""}>MikroTik: ${escapeHtml(r.name)} (${escapeHtml(r.host)})</option>`)
    .join("");

  showModal(`
    <h3>${isEdit ? "Edit Service" : "Add Service"}</h3>
    <label>Service Name</label>
    <input id="f-name" value="${device ? escapeHtml(device.name) : ""}" />
    <label>IP Address</label>
    <input id="f-ip" value="${device ? escapeHtml(device.ipAddress) : ""}" placeholder="10.0.0.1" />
    <label>Category</label>
    <input id="f-category" value="${device ? escapeHtml(device.category || "") : ""}" placeholder="Router / OLT / Switch / Gateway / DNS / External" />
    <label>Monitor Via</label>
    <select id="f-server">
      <option value="local" ${currentServer === "local" ? "selected" : ""}>Local Server (direct ping)</option>
      ${routerOptions}
    </select>
    ${routers.length === 0 ? '<p class="muted" style="margin-top:4px">No MikroTik routers added yet - add one under the MikroTik tab to monitor through it.</p>' : ""}
    <label>Ping Interval (ms, optional)</label>
    <input id="f-interval" type="number" value="${device?.intervalMs || ""}" placeholder="Default: 10000 local / 15000 via MikroTik" />
    <label>Notes</label>
    <textarea id="f-notes">${device ? escapeHtml(device.notes || "") : ""}</textarea>
    <div class="checkbox-row">
      <input type="checkbox" id="f-active" ${device?.isActive !== false ? "checked" : ""} />
      <label style="margin:0">Active monitoring</label>
    </div>
    <div class="modal-actions">
      <button class="btn" id="modal-cancel">Cancel</button>
      <button class="btn primary" id="modal-save">${isEdit ? "Save" : "Add Service"}</button>
    </div>
  `);

  document.getElementById("modal-cancel").onclick = closeModal;
  document.getElementById("modal-save").onclick = async () => {
    const serverChoice = document.getElementById("f-server").value;
    const payload = {
      name: document.getElementById("f-name").value.trim(),
      ipAddress: document.getElementById("f-ip").value.trim(),
      category: document.getElementById("f-category").value.trim() || null,
      mikrotikRouterId: serverChoice === "local" ? null : serverChoice,
      notes: document.getElementById("f-notes").value.trim() || null,
      intervalMs: document.getElementById("f-interval").value ? parseInt(document.getElementById("f-interval").value) : null,
      isActive: document.getElementById("f-active").checked,
    };
    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Saving…";
    try {
      if (isEdit) await api(`/devices/${device.id}`, { method: "PATCH", body: JSON.stringify(payload) });
      else await api("/devices", { method: "POST", body: JSON.stringify(payload) });
      closeModal();
      await loadDevices();
      renderGrid();
    } catch (err) {
      if (isEdit && /not found/i.test(err.message)) {
        alert("This service no longer exists - it may have been deleted, or the app's saved data was reset. Refreshing the list.");
        closeModal();
        await loadDevices();
        renderGrid();
        return;
      }
      alert(err.message);
      saveBtn.disabled = false;
      saveBtn.textContent = isEdit ? "Save" : "Add Service";
    }
  };
}

async function deleteDevice(id) {
  if (!confirm("Delete this service? This cannot be undone.")) return;
  await api(`/devices/${id}`, { method: "DELETE" });
  await loadDevices();
  renderGrid();
}

async function refreshDeviceStats(id) {
  await api(`/devices/${id}/reset-stats`, { method: "POST" });
  const device = devices.find((d) => d.id === id);
  if (device) device.stats = null;
  renderGrid();
}

async function refreshAllStats() {
  if (selected.size > 0) {
    if (!confirm(`Reset ping stats for the ${selected.size} selected service(s) and start fresh reports?`)) return;
    await api("/devices/reset-stats-bulk", { method: "POST", body: JSON.stringify({ deviceIds: [...selected] }) });
    devices.forEach((d) => { if (selected.has(d.id)) d.stats = null; });
  } else {
    if (!confirm("Reset ping stats for all services and start fresh reports?")) return;
    await api("/devices/reset-stats-all", { method: "POST" });
    devices.forEach((d) => (d.stats = null));
  }
  renderGrid();
}

// ---- Traceroute modal ----
async function openTracerouteModal(device) {
  showModal(`
    <h3>Traceroute: ${escapeHtml(device.name)} (${escapeHtml(device.ipAddress)})</h3>
    <p class="muted" id="tr-status">Running traceroute…</p>
    <table class="hop-table hidden" id="tr-table">
      <thead><tr><th>Hop</th><th>IP</th><th>Latency</th><th>Loss</th></tr></thead>
      <tbody id="tr-body"></tbody>
    </table>
    <div class="modal-actions">
      <button class="btn" id="modal-cancel">Close</button>
    </div>
  `);
  document.getElementById("modal-cancel").onclick = closeModal;

  try {
    const result = await api(`/devices/${device.id}/traceroute`, { method: "POST" });
    document.getElementById("tr-status").textContent = `${result.hops.length} hops - completed`;
    document.getElementById("tr-table").classList.remove("hidden");
    const tbody = document.getElementById("tr-body");
    tbody.innerHTML = result.hops
      .map((h) => `<tr><td>${h.hopNumber}</td><td>${h.ip || "*"}</td><td>${fmt(h.latencyMs, "ms", 3)}</td><td>${fmt(h.packetLoss, "%")}</td></tr>`)
      .join("");
  } catch (err) {
    document.getElementById("tr-status").textContent = `Failed: ${err.message}`;
  }
}

// ---- CSV import/export ----
function openImportModal() {
  showModal(`
    <h3>Import Services from CSV</h3>
    <p class="muted">Header row required. Minimum columns: name, ipAddress. Optional: category, pop, vendor, notes.</p>
    <textarea id="csv-input" style="min-height:160px" placeholder="name,ipAddress,category,pop,vendor,notes
Core Router,10.0.0.1,Router,HQ,MikroTik,
OLT-1,10.0.0.3,OLT,HQ,ECOM,"></textarea>
    <div class="modal-actions">
      <button class="btn" id="modal-cancel">Cancel</button>
      <button class="btn primary" id="modal-import">Import</button>
    </div>
    <p id="import-result" class="muted"></p>
  `);
  document.getElementById("modal-cancel").onclick = closeModal;
  document.getElementById("modal-import").onclick = async () => {
    const csv = document.getElementById("csv-input").value;
    try {
      const result = await api("/devices/import-csv", { method: "POST", body: JSON.stringify({ csv }) });
      document.getElementById("import-result").textContent =
        `Imported ${result.imported} device(s).` + (result.errors.length ? ` ${result.errors.length} error(s): ${result.errors.join("; ")}` : "");
      await loadDevices();
      renderGrid();
    } catch (err) {
      document.getElementById("import-result").textContent = `Failed: ${err.message}`;
    }
  };
}

function exportCsv() {
  const url = `/api/devices/export-csv`;
  fetch(url, { headers: { Authorization: `Bearer ${TOKEN}` } })
    .then((res) => res.blob())
    .then((blob) => {
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "devices-export.csv";
      link.click();
    });
}

// ---- Bulk edit ----
function openBulkEditModal() {
  const routerOptions = routers
    .map((r) => `<option value="${r.id}">MikroTik: ${escapeHtml(r.name)}</option>`)
    .join("");

  showModal(`
    <h3>Bulk Edit (${selected.size} services)</h3>
    <p class="muted">Only filled-in fields are applied. Leave a field on its default to skip it.</p>
    <label>Category</label>
    <input id="bf-category" placeholder="leave blank to skip" />
    <label>POP / Location</label>
    <input id="bf-pop" placeholder="leave blank to skip" />
    <label>Vendor</label>
    <input id="bf-vendor" placeholder="leave blank to skip" />
    <label>Monitor Via</label>
    <select id="bf-server">
      <option value="">Don't change</option>
      <option value="local">Local Server (direct ping)</option>
      ${routerOptions}
    </select>
    <label>Ping Interval (ms)</label>
    <input id="bf-interval" type="number" placeholder="leave blank to skip" />
    <label>Active Status</label>
    <select id="bf-active">
      <option value="">Don't change</option>
      <option value="true">Set Active</option>
      <option value="false">Set Inactive</option>
    </select>
    <div class="modal-actions">
      <button class="btn" id="modal-cancel">Cancel</button>
      <button class="btn primary" id="modal-apply">Apply to ${selected.size} services</button>
    </div>
  `);
  document.getElementById("modal-cancel").onclick = closeModal;
  document.getElementById("modal-apply").onclick = async () => {
    const applyBtn = document.getElementById("modal-apply");
    const patch = {};
    const category = document.getElementById("bf-category").value.trim();
    const pop = document.getElementById("bf-pop").value.trim();
    const vendor = document.getElementById("bf-vendor").value.trim();
    const server = document.getElementById("bf-server").value;
    const interval = document.getElementById("bf-interval").value.trim();
    const active = document.getElementById("bf-active").value;
    if (category) patch.category = category;
    if (pop) patch.pop = pop;
    if (vendor) patch.vendor = vendor;
    if (server) patch.mikrotikRouterId = server === "local" ? null : server;
    if (interval) patch.intervalMs = parseInt(interval);
    if (active) patch.isActive = active === "true";

    applyBtn.disabled = true;
    applyBtn.textContent = "Applying…";
    try {
      await api("/devices/bulk-edit", { method: "POST", body: JSON.stringify({ deviceIds: [...selected], patch }) });
      selected.clear();
      closeModal();
      await loadDevices();
      renderGrid();
    } catch (err) {
      alert(err.message);
      applyBtn.disabled = false;
      applyBtn.textContent = `Apply to ${selected.size} services`;
    }
  };
}

async function bulkDeleteSelected() {
  if (selected.size === 0) return;
  if (!confirm(`Delete ${selected.size} selected service(s)? This cannot be undone.`)) return;
  try {
    await api("/devices/bulk-delete", { method: "POST", body: JSON.stringify({ deviceIds: [...selected] }) });
  } catch (err) {
    alert(err.message);
  }
  selected.clear();
  await loadDevices();
  renderGrid();
}

// ============================================================================
// Alert rules
// ============================================================================
async function loadRules() {
  const body = await api("/alerts/rules");
  rules = body.rules;
}

function renderRules() {
  const container = document.getElementById("rules-list");
  if (rules.length === 0) {
    container.innerHTML = `<p class="muted">No alert rules yet. Try "Packet Loss > 1%" or "Offline for 3 consecutive checks".</p>`;
    return;
  }
  container.innerHTML = rules
    .map((r) => `
      <div class="card">
        <div class="card-info">
          <div class="card-title">${escapeHtml(r.name)} ${r.enabled ? "" : '<span class="muted">(disabled)</span>'}</div>
          <div class="card-sub">${r.metric} ${r.operator} ${r.threshold} · consecutive checks: ${r.consecutiveChecks} ${r.telegram ? "· 📨 Telegram" : ""}</div>
        </div>
        <div class="card-actions">
          <button class="btn small" data-toggle-rule="${r.id}">${r.enabled ? "Disable" : "Enable"}</button>
          <button class="btn small danger" data-delete-rule="${r.id}">Delete</button>
        </div>
      </div>
    `)
    .join("");
}

// Rules are fully configured at creation time - there is intentionally no
// edit path. If you need different settings, delete the rule and create a
// new one; this avoids ever editing a rule whose ID has gone stale.
function openRuleModal() {
  const deviceOptions = devices.map((d) => `<option value="${d.id}">${escapeHtml(d.name)}</option>`).join("");
  showModal(`
    <h3>New Alert Rule</h3>
    <label>Rule Name</label>
    <input id="r-name" placeholder="High packet loss" />
    <label>Metric</label>
    <select id="r-metric">
      <option value="OFFLINE">Offline (consecutive failed checks)</option>
      <option value="LATENCY">Latency</option>
      <option value="PACKET_LOSS">Packet Loss</option>
      <option value="JITTER">Jitter</option>
    </select>
    <label>Operator</label>
    <select id="r-operator">
      <option value="GT">Greater than</option>
      <option value="LT">Less than</option>
    </select>
    <label>Threshold</label>
    <input id="r-threshold" type="number" step="0.1" placeholder="e.g. 30 (ms) or 1 (%)" />
    <label>Consecutive checks required</label>
    <input id="r-consecutive" type="number" value="1" min="1" />
    <label>Apply to specific device (optional - leave blank for all devices)</label>
    <select id="r-device"><option value="">All devices</option>${deviceOptions}</select>
    <div class="checkbox-row">
      <input type="checkbox" id="r-telegram" />
      <label style="margin:0">Send Telegram notification (configure under the Settings tab)</label>
    </div>
    <div class="modal-actions">
      <button class="btn" id="modal-cancel">Cancel</button>
      <button class="btn primary" id="modal-save">Create Rule</button>
    </div>
  `);
  document.getElementById("modal-cancel").onclick = closeModal;
  document.getElementById("modal-save").onclick = async () => {
    const saveBtn = document.getElementById("modal-save");
    const payload = {
      name: document.getElementById("r-name").value.trim(),
      metric: document.getElementById("r-metric").value,
      operator: document.getElementById("r-operator").value,
      threshold: parseFloat(document.getElementById("r-threshold").value),
      consecutiveChecks: parseInt(document.getElementById("r-consecutive").value) || 1,
      deviceId: document.getElementById("r-device").value || null,
      telegram: document.getElementById("r-telegram").checked,
    };
    if (!payload.name || isNaN(payload.threshold)) return alert("Name and threshold are required");

    saveBtn.disabled = true;
    saveBtn.textContent = "Saving…";
    try {
      await api("/alerts/rules", { method: "POST", body: JSON.stringify(payload) });
      closeModal();
      await loadRules();
      renderRules();
    } catch (err) {
      alert(err.message);
      saveBtn.disabled = false;
      saveBtn.textContent = "Create Rule";
    }
  };
}

async function toggleRule(id) {
  const rule = rules.find((r) => r.id === id);
  if (!rule) return loadRules().then(renderRules); // stale card - just refresh silently
  try {
    await api(`/alerts/rules/${id}`, { method: "PATCH", body: JSON.stringify({ enabled: !rule.enabled }) });
  } catch {
    // rule may have been deleted elsewhere - refresh rather than show an error for a routine toggle
  }
  await loadRules();
  renderRules();
}

async function deleteRule(id) {
  if (!confirm("Delete this alert rule?")) return;
  try {
    await api(`/alerts/rules/${id}`, { method: "DELETE" });
  } catch {
    // already gone - fine, just refresh
  }
  await loadRules();
  renderRules();
}

// ============================================================================
// Alert events (side panel)
// ============================================================================
async function loadAlertEvents() {
  const body = await api("/alerts/events?open=false");
  const unacknowledgedCount = body.events.filter((e) => !e.acknowledged).length;
  const badge = document.getElementById("alert-count");
  badge.textContent = unacknowledgedCount;
  badge.classList.toggle("hidden", unacknowledgedCount === 0);

  const list = document.getElementById("alerts-list");
  if (body.events.length === 0) {
    list.innerHTML = `<p class="muted">No alerts. Everything looks healthy.</p>`;
    return;
  }
  list.innerHTML = body.events
    .map((e) => `
      <div class="alert-item ${e.severity === "CRITICAL" ? "critical" : ""}">
        <div class="alert-msg">${escapeHtml(e.message)}</div>
        <div class="alert-meta">${timeAgo(e.triggeredAt)} ${e.resolvedAt ? "· recovered" : ""} ${e.acknowledged ? "· acknowledged" : ""}</div>
        <div style="margin-top:6px; display:flex; gap:6px;">
          ${!e.acknowledged ? `<button class="btn small" data-ack="${e.id}">Acknowledge</button>` : ""}
          <button class="btn small danger" data-remove-alert="${e.id}">Remove</button>
        </div>
      </div>
    `)
    .join("");
}

async function ackEvent(id) {
  await api(`/alerts/events/${id}/ack`, { method: "POST" });
  await loadAlertEvents();
}

async function removeAlertEvent(id) {
  await api(`/alerts/events/${id}`, { method: "DELETE" });
  await loadAlertEvents();
}

// ============================================================================
// MikroTik
// ============================================================================
async function loadRouters() {
  const body = await api("/mikrotik");
  routers = body.routers;
}

function renderRouters() {
  const container = document.getElementById("routers-list");
  if (routers.length === 0) {
    container.innerHTML = `<p class="muted">No MikroTik routers added yet.</p>`;
    return;
  }
  container.innerHTML = routers
    .map((r) => `
      <div class="card">
        <div class="card-info">
          <div class="card-title">${escapeHtml(r.name)} <span class="muted">(${escapeHtml(r.host)})</span></div>
          <div class="card-sub">Status: ${r.lastStatus}${r.lastError ? ` · ${escapeHtml(r.lastError)}` : ""}</div>
        </div>
        <div class="card-actions">
          <button class="btn small" data-test-router="${r.id}">Test</button>
          <button class="btn small" data-info-router="${r.id}">Info</button>
          <button class="btn small danger" data-delete-router="${r.id}">Delete</button>
        </div>
      </div>
    `)
    .join("");
}

function openRouterModal() {
  showModal(`
    <h3>Add MikroTik Router</h3>
    <label>Name</label>
    <input id="mt-name" placeholder="Core Router" />
    <label>Host / IP</label>
    <input id="mt-host" placeholder="10.0.0.1" />
    <label>API Port</label>
    <input id="mt-port" type="number" value="8728" />
    <label>Username</label>
    <input id="mt-user" placeholder="admin" />
    <label>Password</label>
    <input id="mt-pass" type="password" />
    <div class="checkbox-row">
      <input type="checkbox" id="mt-tls" />
      <label style="margin:0">Use TLS (API-SSL, port 8729 typically)</label>
    </div>
    <div class="modal-actions">
      <button class="btn" id="modal-cancel">Cancel</button>
      <button class="btn primary" id="modal-save">Add Router</button>
    </div>
  `);
  document.getElementById("modal-cancel").onclick = closeModal;
  document.getElementById("modal-save").onclick = async () => {
    const payload = {
      name: document.getElementById("mt-name").value.trim(),
      host: document.getElementById("mt-host").value.trim(),
      apiPort: parseInt(document.getElementById("mt-port").value) || 8728,
      username: document.getElementById("mt-user").value.trim(),
      password: document.getElementById("mt-pass").value,
      useTls: document.getElementById("mt-tls").checked,
    };
    if (!payload.name || !payload.host || !payload.username || !payload.password) {
      return alert("Name, host, username, and password are required");
    }
    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Saving…";
    try {
      await api("/mikrotik", { method: "POST", body: JSON.stringify(payload) });
      closeModal();
      await loadRouters();
      renderRouters();
      populateServerFilter();
      renderGrid();
    } catch (err) {
      alert(err.message);
      saveBtn.disabled = false;
      saveBtn.textContent = "Add Router";
    }
  };
}

async function testRouter(id) {
  try {
    const result = await api(`/mikrotik/${id}/test`, { method: "POST" });
    alert(`Connected! Router identity: ${result.identity}`);
  } catch (err) {
    alert(`Connection failed: ${err.message}`);
  } finally {
    await loadRouters();
    renderRouters();
  }
}

async function showRouterInfo(id) {
  try {
    const info = await api(`/mikrotik/${id}/info`);
    showModal(`
      <h3>Router Info</h3>
      <p><strong>Identity:</strong> ${escapeHtml(info.identity)}</p>
      <p><strong>Version:</strong> ${escapeHtml(info.version || "–")}</p>
      <p><strong>Board:</strong> ${escapeHtml(info.boardName || "–")}</p>
      <p><strong>Uptime:</strong> ${escapeHtml(info.uptime || "–")}</p>
      <p><strong>CPU Load:</strong> ${escapeHtml(String(info.cpuLoad ?? "–"))}%</p>
      <p><strong>Free Memory:</strong> ${escapeHtml(String(info.freeMemory ?? "–"))}</p>
      <div class="modal-actions"><button class="btn" id="modal-cancel">Close</button></div>
    `);
    document.getElementById("modal-cancel").onclick = closeModal;
  } catch (err) {
    alert(`Failed to fetch info: ${err.message}`);
  }
}

async function deleteRouter(id) {
  if (!confirm("Remove this router?")) return;
  await api(`/mikrotik/${id}`, { method: "DELETE" });
  await loadRouters();
  renderRouters();
  populateServerFilter();
  await loadDevices(); // some services may have lost their assigned router
  renderGrid();
}

// ============================================================================
// Settings (Telegram bot)
// ============================================================================
async function loadSettings() {
  const settings = await api("/settings");
  document.getElementById("settings-telegram-token").value = settings.telegramBotToken || "";
  document.getElementById("settings-telegram-chat").value = settings.telegramChatId || "";

  const note = document.getElementById("settings-env-note");
  if (settings.envFallbackAvailable && !settings.telegramBotToken) {
    note.textContent = "A bot token/chat ID is also set in .env and will be used as a fallback if these fields are left blank.";
    note.classList.remove("hidden");
  } else {
    note.classList.add("hidden");
  }
}

async function saveTelegramSettings() {
  const telegramBotToken = document.getElementById("settings-telegram-token").value.trim();
  const telegramChatId = document.getElementById("settings-telegram-chat").value.trim();
  const status = document.getElementById("settings-status");
  status.textContent = "Saving…";
  status.style.color = "";
  try {
    await api("/settings", { method: "POST", body: JSON.stringify({ telegramBotToken, telegramChatId }) });
    status.textContent = "Saved.";
  } catch (err) {
    status.textContent = `Failed to save: ${err.message}`;
    status.style.color = "var(--red)";
  }
}

async function testTelegramConnection() {
  const telegramBotToken = document.getElementById("settings-telegram-token").value.trim();
  const telegramChatId = document.getElementById("settings-telegram-chat").value.trim();
  const status = document.getElementById("settings-status");
  status.textContent = "Sending test message…";
  status.style.color = "";
  try {
    await api("/settings/telegram/test", {
      method: "POST",
      body: JSON.stringify({ telegramBotToken, telegramChatId }),
    });
    status.textContent = "✅ Test message sent - check your Telegram chat.";
    status.style.color = "var(--green)";
  } catch (err) {
    status.textContent = `❌ ${err.message}`;
    status.style.color = "var(--red)";
  }
}

// ============================================================================
// Modal helpers
// ============================================================================
function showModal(html) {
  document.getElementById("modal").innerHTML = html;
  document.getElementById("modal-backdrop").classList.remove("hidden");
}
function closeModal() {
  document.getElementById("modal-backdrop").classList.add("hidden");
}

// ============================================================================
// Event wiring
// ============================================================================
document.getElementById("login-btn").addEventListener("click", login);
document.getElementById("login-password").addEventListener("keydown", (e) => {
  if (e.key === "Enter") login();
});
document.getElementById("logout-btn").addEventListener("click", logout);

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(`tab-${tab.dataset.tab}`).classList.add("active");
  });
});

document.getElementById("search-input").addEventListener("input", debounce(async () => {
  await loadDevices();
  renderGrid();
}, 250));
["filter-category", "filter-pop", "filter-status", "filter-server", "group-by"].forEach((id) => {
  document.getElementById(id).addEventListener("change", async () => {
    if (id !== "group-by") await loadDevices();
    renderGrid();
  });
});

document.getElementById("add-device-btn").addEventListener("click", () => openDeviceModal());
document.getElementById("refresh-all-btn").addEventListener("click", refreshAllStats);
document.getElementById("import-csv-btn").addEventListener("click", openImportModal);
document.getElementById("export-csv-btn").addEventListener("click", exportCsv);
document.getElementById("bulk-edit-btn").addEventListener("click", openBulkEditModal);
document.getElementById("bulk-delete-btn").addEventListener("click", bulkDeleteSelected);
document.getElementById("add-rule-btn").addEventListener("click", openRuleModal);
document.getElementById("add-router-btn").addEventListener("click", openRouterModal);
document.getElementById("settings-save-btn").addEventListener("click", saveTelegramSettings);
document.getElementById("settings-test-btn").addEventListener("click", testTelegramConnection);

document.getElementById("alerts-btn").addEventListener("click", () => {
  document.getElementById("alerts-panel").classList.remove("hidden");
});
document.getElementById("close-alerts-btn").addEventListener("click", () => {
  document.getElementById("alerts-panel").classList.add("hidden");
});
// Note: the modal intentionally does NOT close on backdrop click/tap.
// A drag or slide gesture inside the form (e.g. scrolling a textarea on
// mobile) was being registered as a tap on the backdrop and closing the
// popup mid-edit. Closing now only happens via each modal's own explicit
// Cancel/Close button, which is stable regardless of touch/scroll gestures.

document.getElementById("select-all").addEventListener("change", (e) => {
  if (e.target.checked) devices.forEach((d) => selected.add(d.id));
  else selected.clear();
  renderGrid();
});

// column sort
document.querySelectorAll("[data-sort]").forEach((th) => {
  th.addEventListener("click", () => {
    const col = th.dataset.sort;
    if (sortState.col === col) sortState.dir *= -1;
    else { sortState.col = col; sortState.dir = 1; }
    renderGrid();
  });
});

// delegated clicks inside the grid / lists
document.body.addEventListener("click", (e) => {
  const t = e.target;
  if (t.dataset.pin) {
    pinned.has(t.dataset.pin) ? pinned.delete(t.dataset.pin) : pinned.add(t.dataset.pin);
    localStorage.setItem("noc_pinned", JSON.stringify([...pinned]));
    renderGrid();
  } else if (t.classList.contains("row-check")) {
    t.checked ? selected.add(t.dataset.id) : selected.delete(t.dataset.id);
    renderGrid();
  } else if (t.dataset.edit) {
    openDeviceModal(devices.find((d) => d.id === t.dataset.edit));
  } else if (t.dataset.delete) {
    deleteDevice(t.dataset.delete);
  } else if (t.dataset.traceroute) {
    openTracerouteModal(devices.find((d) => d.id === t.dataset.traceroute));
  } else if (t.dataset.refresh) {
    refreshDeviceStats(t.dataset.refresh);
  } else if (t.dataset.toggleRule) {
    toggleRule(t.dataset.toggleRule);
  } else if (t.dataset.deleteRule) {
    deleteRule(t.dataset.deleteRule);
  } else if (t.dataset.ack) {
    ackEvent(t.dataset.ack);
  } else if (t.dataset.removeAlert) {
    removeAlertEvent(t.dataset.removeAlert);
  } else if (t.dataset.testRouter) {
    testRouter(t.dataset.testRouter);
  } else if (t.dataset.infoRouter) {
    showRouterInfo(t.dataset.infoRouter);
  } else if (t.dataset.deleteRouter) {
    deleteRouter(t.dataset.deleteRouter);
  }
});

function debounce(fn, ms) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

// periodic refresh of alert badge + reconcile grid every 30s as a safety net
// in case a WS message was missed
setInterval(() => { if (TOKEN) loadAlertEvents(); }, 30000);

// ============================================================================
// Boot
// ============================================================================
if (TOKEN) boot().catch(() => logout("Could not load - please log in again."));
