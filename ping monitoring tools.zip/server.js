require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const path = require("path");
const { v4: uuid } = require("uuid");

const { data, save, flushSync } = require("./lib/db");
const auth = require("./lib/auth");
const scheduler = require("./lib/scheduler");
const statsStore = require("./lib/stats");
const wsService = require("./lib/ws");
const { runTraceroute } = require("./lib/traceroute");
const mikrotik = require("./lib/mikrotik");
const telegram = require("./lib/telegram");

const app = express();
app.use(cors());
app.use(express.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = parseInt(process.env.PORT || "4000", 10);

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

app.post("/api/login", (req, res) => {
  const { password } = req.body;
  const token = auth.login(password);
  if (!token) return res.status(401).json({ error: "Incorrect password" });
  res.json({ token });
});

// everything below requires auth, except login and health
app.use("/api", (req, res, next) => {
  if (req.path === "/login" || req.path === "/health") return next();
  auth.requireAuth(req, res, next);
});

// ---------------------------------------------------------------------------
// Devices
// ---------------------------------------------------------------------------

app.get("/api/devices", (req, res) => {
  const { search, category, pop, vendor, status, server } = req.query;

  let devices = data.devices.map((d) => ({ ...d, stats: statsStore.get(d.id) }));

  if (search) {
    const q = search.toLowerCase();
    devices = devices.filter(
      (d) =>
        d.name.toLowerCase().includes(q) ||
        d.ipAddress.includes(q) ||
        (d.pop || "").toLowerCase().includes(q) ||
        (d.category || "").toLowerCase().includes(q) ||
        (d.vendor || "").toLowerCase().includes(q)
    );
  }
  if (category) devices = devices.filter((d) => d.category === category);
  if (pop) devices = devices.filter((d) => d.pop === pop);
  if (vendor) devices = devices.filter((d) => d.vendor === vendor);
  if (status) devices = devices.filter((d) => (d.stats?.status || "UNKNOWN") === status);
  if (server === "local") devices = devices.filter((d) => !d.mikrotikRouterId);
  else if (server) devices = devices.filter((d) => d.mikrotikRouterId === server);

  res.json({ devices });
});

function validateDeviceInput(body) {
  if (!body.name || !body.name.trim()) return "name is required";
  if (!body.ipAddress || !/^(\d{1,3}\.){3}\d{1,3}$/.test(body.ipAddress)) {
    return "a valid IPv4 address is required";
  }
  return null;
}

app.post("/api/devices", (req, res) => {
  const error = validateDeviceInput(req.body);
  if (error) return res.status(400).json({ error });

  const device = {
    id: uuid(),
    name: req.body.name.trim(),
    ipAddress: req.body.ipAddress.trim(),
    category: req.body.category || null,
    pop: req.body.pop || null,
    vendor: req.body.vendor || null,
    notes: req.body.notes || null,
    isActive: req.body.isActive !== false,
    monitorMethod: req.body.mikrotikRouterId ? "MIKROTIK_NETWATCH" : req.body.monitorMethod || "ICMP",
    mikrotikRouterId: req.body.mikrotikRouterId || null,
    intervalMs: req.body.intervalMs || null,
    createdAt: new Date().toISOString(),
  };

  data.devices.push(device);
  save();

  scheduler.upsert(device);

  res.status(201).json(device);
});

app.patch("/api/devices/:id", (req, res) => {
  const device = data.devices.find((d) => d.id === req.params.id);
  if (!device) return res.status(404).json({ error: "Device not found" });

  if (req.body.ipAddress) {
    const error = validateDeviceInput({ ...device, ...req.body });
    if (error) return res.status(400).json({ error });
  }

  Object.assign(device, req.body);
  // keep monitorMethod consistent with whatever router assignment was just set/cleared
  if ("mikrotikRouterId" in req.body) {
    device.monitorMethod = device.mikrotikRouterId ? "MIKROTIK_NETWATCH" : "ICMP";
  }
  save();

  scheduler.upsert(device);
  // editing and saving a service starts its ping report fresh, since the
  // old accumulated sent/received/latency numbers may no longer reflect
  // what's being monitored (new IP, new interval, new monitor-via server, etc.)
  statsStore.resetStats(device.id);
  wsService.broadcast({ type: "device.stats.update", payload: { deviceId: device.id, reset: true } });

  res.json(device);
});

app.delete("/api/devices/:id", (req, res) => {
  data.devices = data.devices.filter((d) => d.id !== req.params.id);
  scheduler.remove(req.params.id);
  save();
  res.status(204).send();
});

/** Bulk edit: apply a partial patch to many devices at once. */
app.post("/api/devices/bulk-edit", (req, res) => {
  const { deviceIds, patch } = req.body;
  if (!Array.isArray(deviceIds) || deviceIds.length === 0) {
    return res.status(400).json({ error: "deviceIds array is required" });
  }

  let updatedCount = 0;
  for (const device of data.devices) {
    if (deviceIds.includes(device.id)) {
      Object.assign(device, patch);
      if ("mikrotikRouterId" in patch) {
        device.monitorMethod = device.mikrotikRouterId ? "MIKROTIK_NETWATCH" : "ICMP";
      }
      updatedCount++;
      scheduler.upsert(device);
    }
  }
  save();
  res.json({ updatedCount });
});

/** Bulk delete: remove many services at once (used by the grid's multi-select). */
app.post("/api/devices/bulk-delete", (req, res) => {
  const { deviceIds } = req.body;
  if (!Array.isArray(deviceIds) || deviceIds.length === 0) {
    return res.status(400).json({ error: "deviceIds array is required" });
  }
  for (const id of deviceIds) scheduler.remove(id);
  data.devices = data.devices.filter((d) => !deviceIds.includes(d.id));
  save();
  res.json({ deletedCount: deviceIds.length });
});

/** CSV import: name,ipAddress,category,pop,vendor,notes */
app.post("/api/devices/import-csv", (req, res) => {
  const { csv } = req.body;
  if (!csv) return res.status(400).json({ error: "csv text body required" });

  const lines = csv.trim().split("\n");
  const [header, ...rows] = lines;
  const columns = header.split(",").map((c) => c.trim());

  if (!columns.includes("name") || !columns.includes("ipAddress")) {
    return res.status(400).json({ error: "CSV must include at least 'name' and 'ipAddress' columns" });
  }

  let imported = 0;
  const errors = [];

  rows.forEach((row, i) => {
    if (!row.trim()) return;
    const values = row.split(",").map((v) => v.trim());
    const record = {};
    columns.forEach((col, idx) => (record[col] = values[idx] ?? ""));

    const error = validateDeviceInput(record);
    if (error) {
      errors.push(`Row ${i + 2}: ${error}`);
      return;
    }

    const device = {
      id: uuid(),
      name: record.name,
      ipAddress: record.ipAddress,
      category: record.category || null,
      pop: record.pop || null,
      vendor: record.vendor || null,
      notes: record.notes || null,
      isActive: true,
      monitorMethod: "ICMP",
      mikrotikRouterId: null,
      intervalMs: null,
      createdAt: new Date().toISOString(),
    };
    data.devices.push(device);
    scheduler.upsert(device);
    imported++;
  });

  save();
  res.json({ imported, errors });
});

app.get("/api/devices/export-csv", (req, res) => {
  const header =
    "name,ipAddress,category,pop,vendor,status,latencyMs,packetLoss,uptimePercent,lastOfflineAt,notes";
  const rows = data.devices.map((d) => {
    const s = statsStore.get(d.id);
    return [
      d.name,
      d.ipAddress,
      d.category || "",
      d.pop || "",
      d.vendor || "",
      s?.status || "UNKNOWN",
      s?.currentLatencyMs ?? "",
      s?.packetLossPercent ?? "",
      s?.uptimePercent ?? "",
      s?.lastOfflineAt || "",
      (d.notes || "").replace(/,/g, ";"),
    ].join(",");
  });

  const csv = [header, ...rows].join("\n");
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=devices-export.csv");
  res.send(csv);
});

app.get("/api/devices/:id/history", (req, res) => {
  res.json({ history: statsStore.getHistory(req.params.id) });
});

/** "Refresh" - clears accumulated sent/received/min/avg/max/jitter/uptime history so monitoring starts a fresh report for this one service. */
app.post("/api/devices/:id/reset-stats", (req, res) => {
  const device = data.devices.find((d) => d.id === req.params.id);
  if (!device) return res.status(404).json({ error: "Device not found" });
  statsStore.resetStats(device.id);
  wsService.broadcast({ type: "device.stats.update", payload: { deviceId: device.id, reset: true } });
  res.json({ reset: true });
});

/** "Refresh All" - same as above but for every service at once. */
app.post("/api/devices/reset-stats-all", (req, res) => {
  const ids = data.devices.map((d) => d.id);
  statsStore.resetAll(ids);
  for (const id of ids) {
    wsService.broadcast({ type: "device.stats.update", payload: { deviceId: id, reset: true } });
  }
  res.json({ reset: ids.length });
});

/** "Refresh Selected" - same as above but scoped to a chosen set of services (used when rows are checked). */
app.post("/api/devices/reset-stats-bulk", (req, res) => {
  const { deviceIds } = req.body;
  if (!Array.isArray(deviceIds) || deviceIds.length === 0) {
    return res.status(400).json({ error: "deviceIds array is required" });
  }
  statsStore.resetAll(deviceIds);
  for (const id of deviceIds) {
    wsService.broadcast({ type: "device.stats.update", payload: { deviceId: id, reset: true } });
  }
  res.json({ reset: deviceIds.length });
});

// ---------------------------------------------------------------------------
// Traceroute
// ---------------------------------------------------------------------------

app.post("/api/devices/:id/traceroute", async (req, res) => {
  const device = data.devices.find((d) => d.id === req.params.id);
  if (!device) return res.status(404).json({ error: "Device not found" });

  try {
    const result = await runTraceroute(device.ipAddress);
    device.lastTraceroute = result; // most recent run only, kept simple (no historical log table)
    save();
    wsService.broadcast({ type: "traceroute.update", payload: { deviceId: device.id, result } });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Alert rules & events
// ---------------------------------------------------------------------------

app.get("/api/alerts/rules", (req, res) => res.json({ rules: data.alertRules }));

app.post("/api/alerts/rules", (req, res) => {
  const { name, metric, operator, threshold, deviceId, category, consecutiveChecks, telegram } =
    req.body;
  if (!name || !metric || threshold == null) {
    return res.status(400).json({ error: "name, metric, and threshold are required" });
  }

  const rule = {
    id: uuid(),
    name,
    metric, // LATENCY | PACKET_LOSS | OFFLINE | JITTER
    operator: operator || "GT",
    threshold,
    deviceId: deviceId || null,
    category: category || null,
    consecutiveChecks: consecutiveChecks || 1,
    telegram: !!telegram,
    enabled: true,
    createdAt: new Date().toISOString(),
  };
  data.alertRules.push(rule);
  save();
  res.status(201).json(rule);
});

app.patch("/api/alerts/rules/:id", (req, res) => {
  const rule = data.alertRules.find((r) => r.id === req.params.id);
  if (!rule) return res.status(404).json({ error: "Rule not found" });
  Object.assign(rule, req.body);
  save();
  res.json(rule);
});

app.delete("/api/alerts/rules/:id", (req, res) => {
  data.alertRules = data.alertRules.filter((r) => r.id !== req.params.id);
  save();
  res.status(204).send();
});

app.get("/api/alerts/events", (req, res) => {
  const onlyOpen = req.query.open !== "false";
  const events = onlyOpen ? data.alertEvents.filter((e) => !e.resolvedAt) : data.alertEvents;
  const enriched = events.map((e) => ({
    ...e,
    device: data.devices.find((d) => d.id === e.deviceId) || null,
    rule: data.alertRules.find((r) => r.id === e.ruleId) || null,
  }));
  res.json({ events: enriched });
});

app.post("/api/alerts/events/:id/ack", (req, res) => {
  const event = data.alertEvents.find((e) => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: "Event not found" });
  event.acknowledged = true;
  save();
  res.json(event);
});

app.delete("/api/alerts/events/:id", (req, res) => {
  data.alertEvents = data.alertEvents.filter((e) => e.id !== req.params.id);
  save();
  res.status(204).send();
});

// ---------------------------------------------------------------------------
// MikroTik routers
// ---------------------------------------------------------------------------

app.get("/api/mikrotik", (req, res) => {
  res.json({
    routers: data.mikrotikRouters.map(({ password, ...rest }) => rest), // never send password back
  });
});

app.post("/api/mikrotik", (req, res) => {
  const { name, host, apiPort, username, password, useTls } = req.body;
  if (!name || !host || !username || !password) {
    return res.status(400).json({ error: "name, host, username, and password are required" });
  }

  const router = {
    id: uuid(),
    name,
    host,
    apiPort: apiPort || 8728,
    username,
    password, // see README for a note on securing this in real deployments
    useTls: !!useTls,
    lastStatus: "UNKNOWN",
    lastError: null,
    createdAt: new Date().toISOString(),
  };
  data.mikrotikRouters.push(router);
  save();
  const { password: _pw, ...safe } = router;
  res.status(201).json(safe);
});

function findRouterOrThrow(id) {
  const router = data.mikrotikRouters.find((r) => r.id === id);
  if (!router) throw new Error("Router not found");
  return router;
}

app.post("/api/mikrotik/:id/test", async (req, res) => {
  try {
    const router = findRouterOrThrow(req.params.id);
    const result = await mikrotik.testConnection(router);
    router.lastStatus = "ONLINE";
    router.lastError = null;
    save();
    res.json(result);
  } catch (err) {
    const router = data.mikrotikRouters.find((r) => r.id === req.params.id);
    if (router) {
      router.lastStatus = "ERROR";
      router.lastError = err.message;
      save();
    }
    res.status(502).json({ error: "Connection failed", detail: err.message });
  }
});

app.get("/api/mikrotik/:id/info", async (req, res) => {
  try {
    res.json(await mikrotik.getRouterInfo(findRouterOrThrow(req.params.id)));
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("/api/mikrotik/:id/netwatch", async (req, res) => {
  try {
    res.json(await mikrotik.getNetwatch(findRouterOrThrow(req.params.id)));
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("/api/mikrotik/:id/interfaces", async (req, res) => {
  try {
    res.json(await mikrotik.getInterfaces(findRouterOrThrow(req.params.id)));
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("/api/mikrotik/:id/routes", async (req, res) => {
  try {
    res.json(await mikrotik.getRoutingTable(findRouterOrThrow(req.params.id)));
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.post("/api/mikrotik/:id/ping", async (req, res) => {
  try {
    const { target, count } = req.body;
    if (!target) return res.status(400).json({ error: "target is required" });
    res.json(await mikrotik.runRemotePing(findRouterOrThrow(req.params.id), target, count));
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.post("/api/mikrotik/:id/traceroute", async (req, res) => {
  try {
    const { target } = req.body;
    if (!target) return res.status(400).json({ error: "target is required" });
    res.json(await mikrotik.runRemoteTraceroute(findRouterOrThrow(req.params.id), target));
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.delete("/api/mikrotik/:id", (req, res) => {
  data.mikrotikRouters = data.mikrotikRouters.filter((r) => r.id !== req.params.id);
  mikrotik.dropPooledConnection(req.params.id);
  save();
  res.status(204).send();
});

// ---------------------------------------------------------------------------
// Settings (Telegram bot configuration)
// ---------------------------------------------------------------------------

app.get("/api/settings", (req, res) => {
  res.json({
    telegramBotToken: data.settings.telegramBotToken || "",
    telegramChatId: data.settings.telegramChatId || "",
    // lets the UI show whether .env provides a fallback even if nothing is saved here
    envFallbackAvailable: !!(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID),
  });
});

app.post("/api/settings", (req, res) => {
  const { telegramBotToken, telegramChatId } = req.body;
  if (telegramBotToken !== undefined) data.settings.telegramBotToken = telegramBotToken.trim();
  if (telegramChatId !== undefined) data.settings.telegramChatId = telegramChatId.trim();
  save();
  res.json({ saved: true });
});

/**
 * Sends a real test message right now. Body can override token/chatId so the
 * user can test before saving; otherwise falls back to the saved settings,
 * then to .env.
 */
app.post("/api/settings/telegram/test", async (req, res) => {
  const token =
    (req.body.telegramBotToken && req.body.telegramBotToken.trim()) ||
    data.settings.telegramBotToken ||
    process.env.TELEGRAM_BOT_TOKEN;
  const chatId =
    (req.body.telegramChatId && req.body.telegramChatId.trim()) ||
    data.settings.telegramChatId ||
    process.env.TELEGRAM_CHAT_ID;

  try {
    await telegram.sendMessage(
      token,
      chatId,
      "✅ ISP NOC Monitor - test message. If you can see this, alert notifications will reach this chat."
    );
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Reports (CSV)
// ---------------------------------------------------------------------------

app.get("/api/reports/alert-log.csv", (req, res) => {
  const header = "device,ip,rule,severity,message,triggeredAt,resolvedAt,acknowledged";
  const rows = data.alertEvents.map((e) => {
    const device = data.devices.find((d) => d.id === e.deviceId);
    const rule = data.alertRules.find((r) => r.id === e.ruleId);
    return [
      device?.name || "unknown",
      device?.ipAddress || "",
      rule?.name || "unknown",
      e.severity,
      `"${e.message.replace(/"/g, "'")}"`,
      e.triggeredAt,
      e.resolvedAt || "",
      e.acknowledged,
    ].join(",");
  });
  const csv = [header, ...rows].join("\n");
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=alert-log.csv");
  res.send(csv);
});

// ---------------------------------------------------------------------------
// Health + boot
// ---------------------------------------------------------------------------

app.get("/api/health", (req, res) =>
  res.json({ ok: true, scheduledDevices: scheduler.getScheduledCount() })
);

const httpServer = http.createServer(app);
wsService.init(httpServer);
scheduler.start();

httpServer.listen(PORT, () => {
  console.log(`\nISP NOC app running: http://localhost:${PORT}`);
  console.log(`Log in with the ADMIN_PASSWORD from your .env file.\n`);
});

process.on("SIGINT", () => {
  mikrotik.closeAllPooledConnections();
  flushSync();
  process.exit(0);
});
process.on("SIGTERM", () => {
  mikrotik.closeAllPooledConnections();
  flushSync();
  process.exit(0);
});
